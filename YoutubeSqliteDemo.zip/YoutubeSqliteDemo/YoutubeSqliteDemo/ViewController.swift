//
//  ViewController.swift
//  YoutubeSqliteDemo
//
//  Created by Yogesh Patel on 15/12/18.
//  Copyright © 2018 Yogesh Patel. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var txtEmail: UITextField!
    @IBOutlet var txtLname: UITextField!
    @IBOutlet var txtFname: UITextField!
    @IBOutlet var txtPhone: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    @IBAction func btnSaveClick(_ sender: UIButton) {
        
        let modelInfo = SignupModel(fname: txtFname.text!, lname: txtLname.text!, phone: txtPhone.text!, email: txtEmail.text!)
        let isSave = DatabaseManager.getInstance().saveData(modelInfo)
        print(isSave)
        
    }
    
}

