//
//  DatabaseManager.swift
//  YoutubeSqliteDemo
//
//  Created by Yogesh Patel on 15/12/18.
//  Copyright © 2018 Yogesh Patel. All rights reserved.
//

import Foundation
var shareInstance = DatabaseManager()
class DatabaseManager: NSObject{
    
    var database:FMDatabase? = nil
    
    
    class func getInstance() -> DatabaseManager{
        if shareInstance.database == nil{
            shareInstance.database = FMDatabase(path: Util.getPath("Signup.db"))
        }
        return shareInstance
    }
    
    // "INSERT INTO reginfo (name, username, email, password) VALUES(?,?,?,?)"
    func saveData(_ modelInfo:SignupModel) -> Bool{
        shareInstance.database?.open()
        let isSave = shareInstance.database?.executeUpdate("INSERT INTO Signup (fname,lname,phone,email) VALUES (?,?,?,?)", withArgumentsIn: [modelInfo.fname,modelInfo.lname,modelInfo.phone,modelInfo.email])
        shareInstance.database?.close()
        return isSave!
    }
    
}
