//
//  SignupModel.swift
//  YoutubeSqliteDemo
//
//  Created by Yogesh Patel on 15/12/18.
//  Copyright © 2018 Yogesh Patel. All rights reserved.
//

import Foundation

struct SignupModel {
    let fname: String
    let lname: String
    let phone: String
    let email: String
}
